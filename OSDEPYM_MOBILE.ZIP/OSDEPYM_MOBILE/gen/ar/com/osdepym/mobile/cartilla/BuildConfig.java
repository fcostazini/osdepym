/** Automatically generated file. DO NOT MODIFY */
package ar.com.osdepym.mobile.cartilla;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}