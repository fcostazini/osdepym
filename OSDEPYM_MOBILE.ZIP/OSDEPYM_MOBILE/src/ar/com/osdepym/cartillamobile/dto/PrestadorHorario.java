package ar.com.osdepym.cartillamobile.dto;

import com.orm.SugarRecord;

public class PrestadorHorario extends SugarRecord <PrestadorHorario>{

	private Integer idPrestador;
	private String horario;

	public PrestadorHorario (){}

	public PrestadorHorario (Integer idPrestador, String horario) {
		super();
		this.idPrestador = idPrestador;
		this.horario = horario;
	}

	public Integer getIdPrestador() {
		return idPrestador;
	}

	public void setIdPrestador(Integer idPrestador) {
		this.idPrestador = idPrestador;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

}